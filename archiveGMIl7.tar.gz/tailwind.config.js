module.exports = {
    content: [
        './**/*.php',
        './**/*.html',
        './**/*.js',
        '!./node_modules/**/*',
    ],
    theme: {
        extend: {
            colors: {

            },
            fontFamily: {

            },
            spacing: {

            },
        },
    },
    plugins: [

    ],
}